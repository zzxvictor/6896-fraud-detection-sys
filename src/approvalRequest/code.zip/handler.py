def handler(event, context):
    return "Hello World from approval request!"
