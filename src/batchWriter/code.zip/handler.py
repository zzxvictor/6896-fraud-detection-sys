def handler(event, context):
    return "Hello World from batch writer"
