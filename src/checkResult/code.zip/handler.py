def handler(event, context):
    return "Hello World from check result"
